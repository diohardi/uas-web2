<html>
    <head>
        <title>Halaman Kasir</title>
    </head>
    
    <body>
        
        <a href="kasir.php?view=bayar_rj">Bayar Rawat Jalan</a> | 
        <a href="kasir.php?view=bayar_ri">Bayar Rawat Inap</a> |
        <a href="kasir.php?view=bayar_resep">Bayar Resep</a> | 
    </body>
    
</html>